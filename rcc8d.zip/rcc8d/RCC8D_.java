import ij.*;
import ij.plugin.*;
import ij.gui.*;
import ij.process.*; 

/** RCC8D_ for ImageJ,  by G.Landini and D Randell

Spatial relations between binary objects in 2 images.
Send any improvements or bugs to G.Landini@bham.ac.uk

v1.0  27-Apr-2010 
v1,1  28-Apr-2010 fixed tests, not all comparisons are needed
v1.2  28-Apr-2010 3 modes: RCC5 RCC8D and RCC8D+
v1.3  29-Apr-2010 return Null is any of the objects is null
v1.4  30-Apr-2010 sets various properties to the images
v1.5  6-May-2010 rename RCC5 to RCC5D
 To call this plugin from another without having to display the images use for example:

    RCC8D_ rcc8d = new RCC8D_();
    Object[] result = rcc8d.exec(img1, img2, true, true );
    //parameters above are: objectX ImagePlus, objectY ImagePlus, extended, details

v1.6 26-May-2010 speedup via adding rather than averaging images
v1.7 28-Oct-2011 changed b-open and b-close labels
v1.8 29-Oct-2011 changed resolve problems with dilate and erode.
v1.9 30-Oct-2011 more dilation and erosion changes.
v1.10 28-Jun-2012 added extensions
v1.11 10-Oct-2012 no need to compute tendrils for PO*
v1.12 31-Jul-2013 speed up via newSum and not computing unnecessary attributes
*/


public class RCC8D_ implements PlugIn {
        /** Ask for parameters and then execute.*/
        public void run(String arg) {
		
		if (IJ.versionLessThan("1.37f")) return;
		int[] wList = WindowManager.getIDList();

		if (wList==null || wList.length<2) {
			IJ.showMessage("RCC8D", "There must be at least two binary images open.");
			return;
		}
		String[] titles = new String[wList.length];
		for (int i=0, k=0; i<wList.length; i++) {
			ImagePlus imp = WindowManager.getImage(wList[i]);
			if (null !=imp)
				titles[k++] = imp.getTitle();
		}

		// 1 - Obtain the currently active image if necessary:
		// not today

		// 2 - Ask for parameters:
		boolean extended = true, attributes=false, details = false; //, whiteParticles =Prefs.blackBackground;
		GenericDialog gd = new GenericDialog("RCC8D");
		gd.addMessage("Region Connection Calculus v1.12");
		gd.addMessage("See and quote reference:\nRandell DA, Landini G & Galton A. (2013)\nDiscrete mereotopology fo spatial reasoning\nin automated histological image analysis.\nIEEE Trans PAMI 5(3): 568-581.\ndoi: 10.1109/TPAMI.2012.128");
		gd.addMessage("White objects on black background only!");
		gd.addMessage("Uses edge padding when eroding.");
		gd.addChoice("X :", titles, titles[0]);
		gd.addChoice("Y :", titles, titles[1]);
		String [] DisplayOption={"RCC5D", "RCC8D", "RCC8D+"};
		gd.addChoice("Show", DisplayOption, DisplayOption[1]);
		gd.addCheckbox("Attributes", false);
		gd.addCheckbox("Details", true);

		gd.showDialog();
		if (gd.wasCanceled()) return
;
		// 3 - Retrieve parameters from the dialog
		int i1Index = gd.getNextChoiceIndex();
		int i2Index = gd.getNextChoiceIndex();
		String mode = gd.getNextChoice ();
		attributes = gd.getNextBoolean();
		details  = gd.getNextBoolean();

		ImagePlus imp1 = WindowManager.getImage(wList[i1Index]);
		ImagePlus imp2 = WindowManager.getImage(wList[i2Index]);

		if (imp1.getStackSize()>1 || imp2.getStackSize()>1) {
			IJ.showMessage("Error", "Stacks not supported");
			return;
		}
		if (imp1.getBitDepth()!=8 || imp2.getBitDepth()!=8) {
			IJ.showMessage("Error", "Only 8-bit images are supported");
			return;
		}

		if (imp1.isInvertedLut() || imp2.isInvertedLut() ) {
			IJ.showMessage("Error", "No inverted LUTs, please");
			return;
		}


		ImageStatistics stats;
		// Check images are binary. You must check this before calling the exec method.
		stats = imp1.getStatistics();
		if (stats.histogram[0] + stats.histogram[255] != stats.pixelCount){
			IJ.error("8-bit binary mask image (0 and 255) required.");
			return;
		}

		stats = imp2.getStatistics();
			if (stats.histogram[0] + stats.histogram[255] != stats.pixelCount){
			IJ.error("8-bit binary seed image (0 and 255) required.");
			return;
		}

		 // 4 - Execute!
		Object[] result = exec(imp1, imp2, mode, attributes, details);

		// 5 - If all went well, show the image:
		//if (null != result) {
		//	 IJ.log("Result : "+result[0]);
		//	ImagePlus resultImage = (ImagePlus) result[1];
		//	resultImage.show();
		//}
	}
 

	/** Execute the plugin 
	* Warning!: This method does NOT check whether the input images are the right type, this is checked in the setup,
	* so careful when calling this method from another plugin. Make sure both images are binary!!
	*/
	 public Object[] exec(ImagePlus imp1, ImagePlus imp2, String mode, boolean attributes, boolean details) {

		// set options
		IJ.run("Options...", "iterations=1 count=1 black pad edm=Overwrite do=Nothing");
		IJ.run("Colors...", "foreground=white background=black selection=yellow");

		// 0 - Check validity of parameters
		if (null == imp1) return null;
		if (null == imp2) return null;
 
		ImageProcessor ip1, ip2;
//		//20 relations
		int relationNumber =20; // Unknown is default

		int[] relationNumberY = {0, 1, 2, 4, 3, 5, 6, 9, 10, 7, 8, 12, 11, 13, 14, 16, 15, 17, 18, 19, 20};
                             // Y index {0, 1, 2, 3, 4, 5, 6, 7, 8 , 9, 10,11, 12, 13, 14 ,15, 16, 17, 18, 19, 20}

//                                         0      1    2     3      4     5     6      7       8       9       10       11         12        13     14     15        16       17     18     19        20                                               
		String [] relationName1={ "DR", "PO", "EQ", "PP", "PPi", "DC", "EC", "TPP", "NTPP",  "TPPi", "NTPPi", "NCNTPP",  "NCNTPPi", "NC", "PO*", "NTPP+",  "NTPPi+", "DC+", "EC+", "DR_0", "Unknown"};
		String [] relationName2={ "DR", "PO", "EQ", "PPi", "PP", "DC", "EC", "TPPi","NTPPi", "TPP",  "NTPP",  "NCNTPPi", "NCNTPP",  "NC", "PO*", "NTPPi+", "NTPP+",  "DC+", "EC+", "DR_0", "Unknown"};
		String [] attributeName={"non-empty", "b-close", "b-open", "regular", "null-interior", "border", "atomic"};
		String  titleX=imp1.getTitle(), titleY=imp2.getTitle(); //result ="unknown",myResult="unknown", 


		boolean[] attributesX = new boolean[7]; //object 1 attributes
		boolean[] attributesY = new boolean[7]; //object 2 attributes

		//boolean rcc5d= mode.equals("RCC5D");
		boolean rcc8d= mode.equals("RCC8D");
		boolean extended= mode.equals("RCC8D+");
		int[] hist = new int[4]; 
		int hX=0, hY=0, hA=0; //histogram bins of averaged image

		IJ.showStatus("RCC8D...");

		ip1 = imp1.getProcessor();
		ip2 = imp2.getProcessor();

		// 1 - Perform the magic
		ImageStatistics stats;

		// are the objects touching the border?
		if(attributes) {
			attributesX[5] = isBorder(ip1); // X border?
			attributesY[5] = isBorder(ip2); // Yborder?
		}

		// Dilated versions imp3 and imp4
		ImagePlus imp3 = new ImagePlus("_X", ip1.duplicate());
		IJ.run(imp3, "Subtract...", "value=254"); // 0s and 1s  

		ImagePlus imp4 = new ImagePlus("_Y", ip2.duplicate());
		IJ.run(imp4, "Subtract...", "value=253"); // 0s and 2s 

		// Encoding is X =1, Y=2, background=0, then after adding the 2 images one gets
		// X and Y : 3, X alone :1 (X + background) and Y alone: 2 (Y + background)

		ImageCalculator ic = new ImageCalculator();

		hist[0]=0;
		hist[1]=0;
		hist[2]=0;
		hist[3]=0;
		newSum(imp3, imp4, hist);
		hX=hist[1];
		hY=hist[2];
		hA=hist[3];

		//let's analyze the first average
		// X is non-null
		//if (hX+hY+hA) == 0 both X and Y are null
		if ((hX+hA)!=0){
			attributesX[0] =true;
			if(attributes)
				testObject(imp1, attributesX); // null-interior, b-open, b-close, regular ?
		}
		//Y is non-null
		if ((hY+hA)!=0) {
			attributesY[0] =true;
			if(attributes)
				testObject(imp2, attributesY);
		}
		//X is atomic
		if ((hX==1 && hA==0) || (hX==0 && hA==1))
			attributesX[6] = true;
		//Y is atomic
		if ((hY==1 && hA==0) || (hY==0 && hA==1))
			attributesY[6] = true;

		relationNumber=19; //Null
		if (attributesX[0] && attributesY[0]) {
			relationNumber=20; // "Unknown" so one catches non-matching relations
			if (hX==0 && hY==0 && hA!=0) {
				relationNumber=2; //EQ
			}
			else if (hX!=0 && hY!=0 && hA!=0) {
				relationNumber=1; //PO
			}
			else if (hX==0 && hY!=0 && hA!=0) {
				// PP, but which one? TPP or NTPP or any of the extensions?
				relationNumber=3; //PP
				if (rcc8d || extended){
					// test D(X) avg Y
					//Create Dilated version of X
					ImagePlus imp5 = new ImagePlus("_D(X)", imp3.getProcessor().duplicate());
					IJ.run(imp5, "Maximum...", "radius=1");
					ImagePlus imp6 = new ImagePlus("_D(D(X))", imp5.getProcessor().duplicate()); // just in case it is not EC

					hist[0]=0;
					hist[1]=0;
					hist[2]=0;
					hist[3]=0;
					newSum(imp5, imp4, hist);
					hX=hist[1];
					hY=hist[2];
					hA=hist[3];
					//IJ.log(hX+" "+hY+" "+hA); // for debugging
					imp5.close();
					if (hX!=0)
						relationNumber=7; //TPP
					else if  (hX==0 )  {
						relationNumber=8; //NTPP
						if (extended) {
							// this is NTPP or NNTPP
							// test D(D(X)) avg Y
							IJ.run(imp6, "Maximum...", "radius=1");// second dilation

							hist[0]=0;
							hist[1]=0;
							hist[2]=0;
							hist[3]=0;
							newSum(imp6, imp4, hist);
							hX=hist[1];
							hY=hist[2];
							hA=hist[3];

							imp6.close();
							if (hX!=0)
								relationNumber=11; //NCNTPP
							else if  (hX==0)
								relationNumber=15; //NTPP+

						}
					}
				}
			}
			else if (hX!=0 && hY==0 && hA!=0) {
				// PPi, but which one? TPPi or NTPPi or any of the extensions?
				relationNumber=4; //PPi
				if (rcc8d || extended){
					// test X avg D(Y)
					//Create Dilated version of Y 
					ImagePlus imp5 = new ImagePlus("_Y(X)", imp4.getProcessor().duplicate());
					IJ.run(imp5, "Maximum...", "radius=1");
					ImagePlus imp6 = new ImagePlus("_D(D(Y))", imp5.getProcessor().duplicate()); // just in case it is not	 EC
					hist[0]=0;
					hist[1]=0;
					hist[2]=0;
					hist[3]=0;
					newSum(imp5, imp3, hist);
					hX=hist[1];
					hY=hist[2];
					hA=hist[3];
					imp5.close();

					if (hY!=0 )
						relationNumber=9; //TPPi 
					else if  (hY==0 ) {
						relationNumber=10; //NTPPi
						if (extended) {
							// this is NTPPi+ or NNTPPi
							// test X avg D(D(Y))
							IJ.run(imp6, "Maximum...", "radius=1");// second dilation

							hist[0]=0;
							hist[1]=0;
							hist[2]=0;
							hist[3]=0;
							newSum(imp6, imp3, hist);
							hX=hist[1];
							hY=hist[2];
							hA=hist[3];

							imp6.close();
							if (hY!=0)
								relationNumber=12; //NCNTPPi
							else if  (hY==0)                              
								relationNumber=16; //NTPPi+
						}
					}
				}
			}
			else if (hX!=0 && hY!=0 && hA==0) {
				// this is DR either DC, EC or NC
				relationNumber=0; //DR
				if (rcc8d || extended){
					// test for DC or EC
					ImagePlus imp5 = new ImagePlus("_D(X)",  imp3.getProcessor().duplicate());
					IJ.run(imp5, "Maximum...", "radius=1");
					ImagePlus imp6 = new ImagePlus("_D(D(X))", imp5.getProcessor().duplicate()); // just in case it is not EC

					hist[0]=0;
					hist[1]=0;
					hist[2]=0;
					hist[3]=0;
					newSum(imp5, imp4, hist);
					hX=hist[1];
					hY=hist[2];
					hA=hist[3];
					imp5.close();

					if ( hA!=0){
						relationNumber=6; //EC
						if (extended) {
							// if EC, then find out if this is EC+ or 8-connected PO*, 
							// diagonal lines crossing without overlapping pixels, possible in 8-conn objects

							//-- find 2x2 pattern of diagonal crossing
							imp5 = new ImagePlus("_2", ip1.duplicate());
							ImagePlus imp7 = new ImagePlus("_1", ip1.duplicate());
							IJ.run(imp7, "BinaryHitOrMiss ", "kernel_a=[1 0 2 0 1 2 2 2 2 ] rotations=none  white"); //_1
							IJ.run(imp5, "BinaryHitOrMiss ", "kernel_a=[0 1 2 1 0 2 2 2 2 ] rotations=none  white"); //_2

							ImagePlus imp9 = new ImagePlus("_4", ip2.duplicate());
							ImagePlus imp8 = new ImagePlus("_3", ip2.duplicate());
							IJ.run(imp8, "BinaryHitOrMiss ", "kernel_a=[1 0 2 0 1 2 2 2 2 ] rotations=none  white"); //_3
							IJ.run(imp9, "BinaryHitOrMiss ", "kernel_a=[0 1 2 1 0 2 2 2 2 ] rotations=none  white"); //_4
							ic.run("And", imp7, imp9); // 1 & 4 into imp7 
							ic.run("And", imp5, imp8); // 2 & 3 into imp5
							ic.run("Or", imp7, imp5); // 1 & 2 into imp7
							stats = imp7.getStatistics();
							if (stats.histogram[255] !=0)
								relationNumber=14; //PO*
							else
								relationNumber=18; //EC+
							imp5.close();
							imp7.close();
							imp8.close();
							imp9.close();
						}
					}
					else if  (hA==0) {
						relationNumber=5; //DC
						if (extended) {
							// this is DC+ or NC
							// test D(D(X)) avg Y
							IJ.run(imp6, "Maximum...", "radius=1");// second dilation

							hist[0]=0;
							hist[1]=0;
							hist[2]=0;
							hist[3]=0;
							newSum(imp6, imp4, hist);
							hX=hist[1];
							hY=hist[2];
							hA=hist[3];

							if (hA!=0)
								relationNumber=13; //NC
							 else if  (hA==0) 
								relationNumber=17; //DC+
						}
					}
					imp6.close();
				}
			}
		}
		imp3.close();
		imp4.close();

		if (details) {
			if(attributes)
				IJ.log("------- " + mode+" -------\n" +
				"X: "+titleX+"\n"+
				attributeName[0]+": "+attributesX[0]+"\n"+
				attributeName[1]+": "+attributesX[1]+"\n"+
				attributeName[2]+": "+attributesX[2]+"\n"+
				attributeName[3]+": "+attributesX[3]+"\n"+
				attributeName[4]+": "+attributesX[4]+"\n"+
				attributeName[5]+": "+attributesX[5]+"\n"+
				attributeName[6]+": "+attributesX[6]+"\n"+
				"Y: "+titleY+"\n"+
				attributeName[0]+": "+attributesY[0]+"\n"+
				attributeName[1]+": "+attributesY[1]+"\n"+
				attributeName[2]+": "+attributesY[2]+"\n"+
				attributeName[3]+": "+attributesY[3]+"\n"+
				attributeName[4]+": "+attributesY[4]+"\n"+
				attributeName[5]+": "+attributesY[5]+"\n"+
				attributeName[6]+": "+attributesY[6]+"\n"+
				"Result : "+relationNumber +"\n"+relationName1[relationNumber]);
			else
				IJ.log("------- " + mode+" -------\n" +
				"X: "+titleX+"\n"+
				attributeName[0]+": "+attributesX[0]+"\n"+
				attributeName[6]+": "+attributesX[6]+"\n"+
				"Y: "+titleY+"\n"+
				attributeName[0]+": "+attributesY[0]+"\n"+
				attributeName[6]+": "+attributesY[6]+"\n"+
				"Result : "+relationNumber +"\n"+relationName1[relationNumber]);
		}
		// set the properties to image X 
		imp1.setProperty("RCC", relationName1[relationNumber]); // so the property of X rel Y can be retrieved frmo a macro
		imp1.setProperty("RCCNum", String.valueOf(relationNumber)); // so the property of X rel Y can be parsed  from a macro as an integer
		imp1.setProperty("mode", mode);
		imp1.setProperty("non-empty", attributesX[0]?"true":"false");
		if(attributes){
			imp1.setProperty("b-close", attributesX[1]?"true":"false");
			imp1.setProperty("b-open", attributesX[2]?"true":"false");
			imp1.setProperty("regular", attributesX[3]?"true":"false");
			imp1.setProperty("null-interior", attributesX[4]?"true":"false");
			imp1.setProperty("border", attributesX[5]?"true":"false");
		}
		imp1.setProperty("atomic", attributesX[6]?"true":"false");
		// set the properties to image Y
		imp2.setProperty("RCC", relationName2[relationNumber]); // so the property of Y rel X can be retrieved frmo a macro
		imp2.setProperty("RCCNum", String.valueOf(relationNumberY)); // so the property of Y rel X can be parsed  from a macro as an integer
		imp2.setProperty("mode", mode);
		imp2.setProperty("non-empty", attributesY[0]?"true":"false");
		if(attributes){
			imp2.setProperty("b-close", attributesY[1]?"true":"false");
			imp2.setProperty("b-open", attributesY[2]?"true":"false");
			imp2.setProperty("regular", attributesY[3]?"true":"false");
			imp2.setProperty("null-interior", attributesY[4]?"true":"false");
			imp2.setProperty("border", attributesY[5]?"true":"false");
		}
		imp2.setProperty("atomic", attributesY[6]?"true":"false");

		return null;// new Object[]{relationName1[relationNumber]};
        }

	boolean isBorder(ImageProcessor ip){
		// find if any pixel intersects the border of the image
		int w=ip.getWidth();
		int ye=ip.getHeight()-1;
		int xe=w-1;
		boolean border=false;
		int total=0;

		for(int x=0;x<w;x++){
			total+=ip.get(x,0);
			total+=ip.get(x,ye);
		}
		for(int y=1;y<ye;y++){
			total+=ip.get(0,y);
			total+=ip.get(xe,y);
		}
		if (total!=0) border = true;

		return border;
	}

	void testObject(ImagePlus imp, boolean [] attributes){
		// attributes{"non-empty", "b-close", "b-open", "regular", "null-interior", "border", "atomic"}
		// some [0], [5], [6] already set
		ImageStatistics stats;

		ImageCalculator ic = new ImageCalculator();

		// is b-open
		ImagePlus impO = new ImagePlus("_Open", imp.getProcessor().duplicate());
		IJ.run(impO, "Erode", "");
		//ImageProcessor ipO = impO.getProcessor();
		//ipO.dilate();;//  E then D exact opening (operations are inverted) as the option was set to pad edges
		stats = impO.getStatistics();
			if (stats.histogram[255] ==0)
				attributes[4]=true; // null-interior

		IJ.run(impO, "Dilate", "");
		//ipO.erode();
		ImagePlus impR=ic.run("Xor create", imp, impO);
		stats = impR.getStatistics();
		if (stats.histogram[255] ==0)
			attributes[2]=true; // is b-open
		impR.close();

		// is b-close
		ImagePlus impC = new ImagePlus("_Close", imp.getProcessor().duplicate());

		IJ.run(impC, "Dilate", "");
		IJ.run(impC, "Erode", "");
		//ImageProcessor ipC = impC.getProcessor();
		//ipC.erode();;//  D then E exact closing (operations are inverted) as the option was set to pad edges
		//ipC.dilate();
		impR=ic.run("Xor create", imp, impC);
		stats = impR.getStatistics();
		if (stats.histogram[255] ==0)
			attributes[1]=true; // is b-close
		impR.close();

		// is regular:
		ic.run("Xor ", impO, impC);
		stats = impO.getStatistics();
		if (stats.histogram[255] ==0)
			attributes[3]=true; // is regular
		impO.close();
		impC.close();
	}

	void newSum(ImagePlus imp3, ImagePlus imp4, int [] hist){
		// return the counts of the sum of the two images
		ImageProcessor ipx=imp3.getProcessor();
		ImageProcessor ipy=imp4.getProcessor();

		byte[] pixelX = (byte []) ipx.getPixels();
		byte[] pixelY = (byte []) ipy.getPixels();

		int sizeA = pixelX.length;
		int a, b, c;
		for(int i=0;i<sizeA;i++) {
			a=(int) pixelX[i];
			b=(int) pixelY[i];
			c=a+b;
			hist[c]++;
		}
	}

}
