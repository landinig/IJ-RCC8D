import ij.*;
import ij.plugin.*;
import ij.gui.*;
import ij.process.*;
import ij.measure.*;
import ij.text.*;
import java.awt.*;
import java.util.BitSet;

/** RCC8D_UF_Multi for ImageJ, by G.Landini and D.A.Randell

Spatial relations between multiple binary regions in 2 images.
Send any improvements or bugs to G.Landini@bham.ac.uk
Versions:
RCC8D_Multi 
1.0  03 Aug 2012 Released. Original version

RCC8D_UF_Multi_fast (experimental, not released)
1.1  26 Oct 2015 do not show the Results Table
1.2  07 Jun 2016 use new Particles8 call speedup
1.3  22 Aug 2016 speed up shortcut by avoiding DC checks
1.4  22 Aug 2016 speed up shortcut by avoiding EQ checks
1.5  30 Nov 2016 fixed DC and EQ speed up, so it is not applied in RCC8D+ mode (because NC is a type of DC)
1.6  01 Dec 2016 fixed counts of EQ in RCC8D+
1.7  21 Jan 2017 call binary labelling without showing, plugin returns table and label images.
1.8  02 Jul 2017 fixed reporting processing time per processed relation

RCC8D_UF_Multi plugin 
2.0  01/Oct/2017 new algorithm, fast RCC5D, RCC8D and some extensions (RCC8D+)
2.1  07/Oct/2017 speedup, simpler sum of overlaps
2.2  08/Oct/2017 output log made easier to parse
2.3  19/Mar/2019 speedup, pre-compute forward mask pointers 
2.4  28/Mar/2019 speedup, use an array instead of image to store the accumulator for RCC8D/+
2.5  10/Apr/2019 implemented more RCC8D+ relations
*/


public class RCC8D_UF_Multi implements PlugIn {
		/** Ask for parameters and then execute.*/
		public void run(String arg) {

		if (IJ.versionLessThan("1.43s")) return;
		int[] wList = WindowManager.getIDList();

		if (wList==null || wList.length<2) {
			IJ.showMessage("RCC8D_UF_Multi", "There must be at least two binary images open.");
			return;
		}
		String[] titles = new String[wList.length];
		for (int i=0, k=0; i<wList.length; i++) {
			ImagePlus imp = WindowManager.getImage(wList[i]);
			if (null !=imp)
				titles[k++] = imp.getTitle();
		}

		// 1 - Obtain the currently active image if necessary:
		// not today

		// 2 - Ask for parameters:
		boolean details = true, progress=false, legend=false, sameImage=false; 	//, whiteParticles =Prefs.blackBackground;
		GenericDialog gd = new GenericDialog("RCC8D_UF_Multi");
		gd.addMessage("Region Connection Calculus\nMultiple Regions v2.5");
		gd.addMessage("Please reference:\nRandell DA, Landini G & Galton A.\nDiscrete mereotopology for spatial\nreasoning in automated histological\nimage analysis. IEEE Trans PAMI,\n35(3): 568-581, 2013.");
		gd.addMessage("White regions on black background only!");
		gd.addMessage("Uses edge padding when eroding.");
		gd.addChoice("X :", titles, titles[0]);
		gd.addChoice("Y :", titles, titles[1]);
		String [] DisplayOption = {"RCC5D", "RCC8D", "RCC8D+"};
		gd.addChoice("Show", DisplayOption, DisplayOption[0]);
		gd.addCheckbox("Details", true);
		gd.addCheckbox("Progress", false);
		gd.addCheckbox("Legend", false);
		gd.addMessage("Any existing RCC table will be overwritten");

		gd.showDialog();
		if (gd.wasCanceled()) return;

		// 3 - Retrieve parameters from the dialog
		int i1Index = gd.getNextChoiceIndex();
		int i2Index = gd.getNextChoiceIndex();
		String mode = gd.getNextChoice ();
		details = gd.getNextBoolean();
		progress = gd.getNextBoolean();
		legend = gd.getNextBoolean();

		ImagePlus imp1 = WindowManager.getImage(wList[i1Index]);
		ImagePlus imp2 = WindowManager.getImage(wList[i2Index]);

		if (imp1.getStackSize()>1 || imp2.getStackSize()>1) {
			IJ.showMessage("Error", "Stacks not supported");
			return;
		}
		
		if (imp1.getBitDepth()!=8 || imp2.getBitDepth()!=8) {
			IJ.showMessage("Error", "Only 8-bit images are supported");
			return;
		}

		if (imp1.isInvertedLut() || imp2.isInvertedLut() ) {
			IJ.showMessage("Error", "No inverted LUTs, please");
			return;
		}

		ImageStatistics stats; 	// Check images are binary before calling the exec method.
		stats = imp1.getStatistics();
		if (stats.histogram[0] + stats.histogram[255] != stats.pixelCount) {
			IJ.error("8-bit binary mask image (0 and 255) required.");
			return;
		}

		stats = imp2.getStatistics();
			if (stats.histogram[0] + stats.histogram[255] != stats.pixelCount) {
			IJ.error("8-bit binary seed image (0 and 255) required.");
			return;
		}

		// 4 - Execute!
		Object[] result = exec(imp1, imp2, mode, details, progress, legend);

		// 5 - If all went well, show the image:
		if (null != result) {
			// IJ.log("Result : "+result[0]);
			ImagePlus resultImage = (ImagePlus) result[0];
			resultImage.show();
			if(legend){
				ImagePlus legendImage = (ImagePlus) result[1];
				legendImage.show();
			}
		}
	}
 

	/** Execute the plugin 
	* Warning!: This method does NOT check whether the two input images are binary, this is checked in the setup,
	*  so careful when calling this method from another plugin. Make sure both images are binary!!
	*/
	 public Object[] exec(ImagePlus imp1, ImagePlus imp2, String mode, boolean details, boolean progress, boolean legend) {

		// set options
		IJ.run("Options...", "iterations=1 count=1 black pad edm=Overwrite do=Nothing");
		IJ.run("Colors...", "foreground=white background=black selection=yellow");

		// 0 - Check validity of parameters
		if (null == imp1) return null;
		if (null == imp2) return null;
		ImageProcessor ip1, ip2;

		//                         0      1    2     3      4     5     6      7       8       9       10       11         12        13    14      15        16       17     18     19        20
		String [] relationName1={ "DR", "PO", "EQ", "PP", "PPi", "DC", "EC", "TPP", "NTPP",  "TPPi", "NTPPi", "NCNTPP",  "NCNTPPi", "NC", "PO*", "NTPP+",  "NTPPi+", "DC+", "EC+", "DR_0", "Unknown"};

		int nX=0, nY=0, nO=0, i, j, x, y, px, py, nx, ny, p2x, p2y, n2x, n2y, yoffset=0, nXtnY;
		int[] slattice;
		long startTime;
		//long startTime8=0;
		byte[] pixels = null;
		byte bx, by;
		boolean bz;
		
		if (mode.equals("RCC8D")) {
			slattice= new int[] {1, 2, 5, 6, 7, 8, 9, 10, 19, 20}; //RCC8D
		}
		else if (mode.equals("RCC8D+")) {
			slattice= new int[] {1, 2, 7, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
		}
		else {
			slattice= new int[] {0, 1, 2, 3, 4, 19, 20}; //RCC5D
		}

		int[] output = {20, 20, 20, 1, 4, 3, 2, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}; //look up table to compute RCC5D.
		//       index {0,  1,  2,  3, 4, 5, 6, 7,  8 , 9,  10, 11, 12, 13, 14 ,15, 16, 17, 18, 19, 20}; //"Unknown" (20) means unexpected results

		IJ.showStatus("RCC8D_Multi...");
		startTime = System.currentTimeMillis();

		if (progress)
			IJ.log("---- RCC8D_Multi - Tests ----");
		ip1 = imp1.getProcessor();
		ip2 = imp2.getProcessor();

		int width = ip1.getWidth();
		int height = ip1.getHeight();
		int wm1 = width - 1;
		int hm1 = height - 1;

		ImageProcessor ip3=null, ip4=null, ipT;
		ImagePlus imp3, imp4, imp5, imp6, impT=null;

		BinaryLabel_ bl = new BinaryLabel_();
		
		Object[] result = bl.exec(imp1, "LabelledX", true, false);
		imp3 = (ImagePlus) result[1];
				
		result = bl.exec(imp2, "LabelledY", true, false);
		imp4 = (ImagePlus) result[1];
		//imp3.show();
		//imp4.show();

		imp5 = new ImagePlus("X_", imp1.getProcessor().duplicate());
		IJ.run(imp5, "Subtract...", "value=254"); // 0s and 1s
		imp6 = new ImagePlus("Y_", imp2.getProcessor().duplicate());
		IJ.run(imp6, "Subtract...", "value=253"); // 0s and 2s

		ImageCalculator ic = new ImageCalculator();
		ic.run("Add", imp5, imp6); // Create overlapping regions with value 3
		//imp5.show();
		imp6.close();

		imp6 = ic.run("AND create", imp1, imp2);// Create binary overlapping regions
		//imp6.show();

		Particles8_ p8 = new Particles8_();
		p8.exec(imp1, imp5, true, false, false, false, "Particles", false, 0, 0, false, true);
		// exe (imp, imp2, white, delborder, label, morpho, option, minmax, min, max, show, overwrite);

		ResultsTable rt = ResultsTable.getResultsTable();
		nX = rt.getCounter();
		//if (nX==0) IJ.log("No regions found in image X: "+imp1.getTitle());		

		int minX[] = new int[nX];

		for (i=0; i<nX; i++)
			minX[i] = (int) rt.getValue("GrMin", i);

		p8.exec(imp2, imp5, true, false, false, false, "Particles", false, 0, 0, false, true);
		// exe (imp, imp2, white, delborder, label, morpho, option, minmax, min, max, show, overwrite);
		
		rt = ResultsTable.getResultsTable();
		nY = rt.getCounter();
		//if (nY==0) IJ.log("No regions found in image Y: "+imp2.getTitle());

		//Maximum size of the RCC table is 2147483647 entries (46340 x 46340 if the same number of regions in each image)
		if (((long)nX * (long)nY) > 2147483647) {
			IJ.log("Too many regions, cannot create table.");
			return null;
		}
		else
			nXtnY = nX * nY; // Total number of relations

		 if (nXtnY == 0) {
			//No regions, show an empty histogram and exit
			if (details) {
				startTime=System.currentTimeMillis() - startTime;
				IJ.log("---- RCC8D_UF_Multi ----");
				IJ.log("ImageX: " + imp1.getTitle());
				IJ.log("RegionsX: " + nX);
				IJ.log("ImageY: " + imp2.getTitle());
				IJ.log("RegionsY: " + nY);
				IJ.log("Mode: " + mode);
				IJ.log("Relations: " + nXtnY);
				IJ.log("O-relations: " + nO);
				IJ.log("Processing_time_(sec.): " + startTime / 1000.0);
				for (i=0; i<slattice.length-2; i++) IJ.log(""+slattice[i]+" "+relationName1[slattice[i]]+":  0");
			}
			return null;
		}

		int minY[] = new int[nY];
		
		for (i=0; i<nY; i++) 
			minY[i] = (int) rt.getValue("GrMin", i);
		
		// Which region in image X does the overlap belong to?
		p8.exec(imp6, imp3, true, false, false, false, "Particles", false, 0, 0, false, true);
		// exe (imp, imp2, white, delborder, label, morpho, option, minmax, min, max, show, overwrite);
		
		rt = ResultsTable.getResultsTable();
		nO = rt.getCounter(); // Number of overlapping regions

		int ovX[] = new int [nO];
		int rel[] = new int [nO];

		for (i=0; i<nO; i++)
			ovX[i] = (int) rt.getValue("GrMin", i) - 1;

		// Which region in image Y does the overlap belong to?
		p8.exec(imp6, imp4, true, false, false, false, "Particles", false, 0,0, false, true);
		// exe (imp, imp2, white, delborder, label, morpho, option, minmax, min, max, show, overwrite);

		int ovY[] = new int[nO];

		for (i=0; i<nO; i++)
			ovY[i] = (int) rt.getValue("GrMin", i) - 1;
		
		for (i=0; i<nO; i++) 
			rel[i] = output[minX[ovX[i]] + minY[ovY[i]]]; // Assign the relation from the look up table

		if (progress) {
			for (i=0; i<nO; i++) 
				IJ.log("Overlap " + i + " X:" + ovX[i] + " Y:" + ovY[i] + " -->" + rel[i] + " " + relationName1[rel[i]]);
		}
		
		imp5.close();
		imp6.close();

		// If the RCC table already exists from a previous analysis, close it
		if (WindowManager.getFrame("RCC")!=null) {
			IJ.selectWindow("RCC");
			impT = IJ.getImage();
			impT.close();
		}

		// Create RCC table image
		impT = IJ.createImage("RCC", "8-bit Black", nX, nY, 1); //Defaults to 0 which is DR in RCC5D
		ipT = impT.getProcessor();
		pixels =(byte []) ipT.getPixels();

		for (i=0; i<nO; i++)
			pixels[ovX[i] + ovY[i] * nX]= (byte) rel[i];

		IJ.run(impT, "glasbey", "");
		impT.setProperty("mode", mode);
		impT.setProperty("imageX", imp1.getTitle());
		impT.setProperty("imageY", imp2.getTitle());

		int yp1, yp2, pxm1, xp1, xp2, xm1, xm2;
		boolean pxb, pyb;

		// Compute RCC8D from the RCC5D table and adjacency tests (pixel patterns)
		if (mode.equals("RCC8D") || mode.equals("RCC8D+")) {
			//startTime8 = System.currentTimeMillis();
			byte accum[] = new byte[nXtnY];
			ip3 = imp3.getProcessor(); //lablled X
			ip4 = imp4.getProcessor(); //labelled Y

			// Accumulate adjacency patterns of 2 regions over the unseen four pixels of the 3x3 forward mask
			for (y=0; y<height; y++) {
				yp1 = y + 1;
				for (x = 0; x < width; x++) {
					px = (int) ip3.getPixelValue(x,y);
					py = (int) ip4.getPixelValue(x,y);
					pxb = (px == 0);
					pyb = (py == 0);

					xp1 = x + 1;
					xm1 = x - 1;

					if (x<wm1) {
						nx = (int) ip3.getPixelValue(xp1,y);
						ny = (int) ip4.getPixelValue(xp1,y);
						if ((pxb && !pyb && nx!=0 && ny==0) || (!pxb && pyb && nx==0 && ny!=0))  accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 255; // 2 regions adjacent
						if ((pxb && pyb && nx!=0 && ny!=0)  || (!pxb && !pyb && nx==0 && ny==0)) accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 127; // overlap adjacent to bckg
					}

					if (x<wm1 && y<hm1) {
						nx = (int) ip3.getPixelValue(xp1,yp1);
						ny = (int) ip4.getPixelValue(xp1,yp1);
						if ((pxb && !pyb && nx!=0 && ny==0) || (!pxb && pyb && nx==0 && ny!=0))  accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 255;
						if ((pxb && pyb && nx!=0 && ny!=0)  || (!pxb && !pyb && nx==0 && ny==0)) accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 127;
					}

					if (y<hm1) {
						nx = (int) ip3.getPixelValue(x,yp1);
						ny = (int) ip4.getPixelValue(x,yp1);
						if ((pxb && !pyb && nx!=0 && ny==0) || (!pxb && pyb && nx==0 && ny!=0))  accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 255;
						if ((pxb && pyb && nx!=0 && ny!=0)  || (!pxb && !pyb && nx==0 && ny==0)) accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 127;
					}

					if (x>0 && y<hm1) {
						nx = (int) ip3.getPixelValue(xm1,yp1);
						ny = (int) ip4.getPixelValue(xm1,yp1);
						if ((pxb && !pyb && nx!=0 && ny==0) || (!pxb && pyb && nx==0 && ny!=0))  accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 255;
						if ((pxb && pyb && nx!=0 && ny!=0)  || (!pxb && !pyb && nx==0 && ny==0)) accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)] = (byte) 127;
					}
				}
			}

			//startTime8 = System.currentTimeMillis()-startTime8;
			//IJ.log("Scan8:" + startTime8);
			//startTime8 = System.currentTimeMillis();

			// Process the RCC5D table into RCC8D according to adjacency test
			for (y=0; y<nY; y++) {
				yoffset = y * nX;
				for (x=0; x<nX; x++) {
					i = x + yoffset;
					bx = accum[i]; // adjacency test result
					by = pixels[i]; // RCC5D table

					if (by == (byte) 0) {
						if (bx == (byte) 255)
							pixels[i] = (byte) 6; //if DR and regions are adjacent -> EC
						else 
							pixels[i] = (byte) 5; //DC
					}
					else if (by == (byte) 3) {
						if (bx == (byte) 127)
							pixels[i] = (byte) 7; //if PP and overlap is adjacent to background -> TPP
						else
							pixels[i] = (byte) 8; //NTPP
					}
					else if (by == (byte) 4) {
						if (bx == (byte) 127)
							pixels[i] = (byte) 9; //if PPi and overlap is adjacent to background -> TPPi
						else
							pixels[i] = (byte) 10; //NTPPi
					}
				}
			}
			//startTime8 = System.currentTimeMillis()-startTime8;
			//IJ.log("Process8:" + startTime8);

			if (mode.equals("RCC8D+")) {
				int wm2 = wm1 - 1;
				int hm2 = hm1 - 1;
				BitSet b1 = new BitSet(nXtnY); //Use BitSet to avoid 'out of memory' with the large tables
				for (i = 0; i < accum.length; i++)
					accum[i] = (byte) 0; //re-initialise array

				//startTime8 = System.currentTimeMillis();
				for (y=0; y<height; y++) {
					yp1 = y + 1;
					yp2 = y + 2;
					for (x=0; x<width; x++) {
						px = (int) ip3.getPixelValue(x,y);
						py = (int) ip4.getPixelValue(x,y);
						pxm1 = px - 1;
						xp1 = x + 1;
						xp2 = x + 2;
						xm1 = x - 1;
						xm2 = x - 2;
						j = nX * (py - 1);
						i = pxm1 + j;
						
						// Accumulate adjacency of 2 regions over the unseen eight outer pixels of the 5x5 forward mask
						if (x<wm2) {
							nx = (int) ip3.getPixelValue(xp2,y);
							ny = (int) ip4.getPixelValue(xp2,y);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;
							
							// The following test finds out if there is a background (or not-same region) pixel 
							// NC-adjacent to the overlap (to compute NCNTPP/NTPP+ and the inverted relations)
							// It tests nx!=px because there could be a 3rd region in EC to a NTPP/i pair.
							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x<wm2 && y<hm1) {
							nx = (int) ip3.getPixelValue(xp2,yp1);
							ny = (int) ip4.getPixelValue(xp2,yp1);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x<wm2 && y<hm2) {
							nx = (int) ip3.getPixelValue(xp2,yp2);
							ny = (int) ip4.getPixelValue(xp2,yp2);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x<wm1 && y<hm2) {
							nx = (int) ip3.getPixelValue(xp1,yp2);
							ny = (int) ip4.getPixelValue(xp1,yp2);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (y<hm2) {
							nx = (int) ip3.getPixelValue(x,yp2);
							ny = (int) ip4.getPixelValue(x,yp2);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x>0 && y<hm2) {
							nx = (int) ip3.getPixelValue(xm1,yp2);
							ny = (int) ip4.getPixelValue(xm1,yp2);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x>1 && y<hm2) {
							nx = (int) ip3.getPixelValue(xm2,yp2);
							ny = (int) ip4.getPixelValue(xm2,yp2);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}

						if (x>1 && y<hm1) {
							nx = (int) ip3.getPixelValue(xm2,yp1);
							ny = (int) ip4.getPixelValue(xm2,yp1);
							if (px!=0 && ny!=0) accum[pxm1+nX*(ny-1)] = (byte) 255;
							if (nx!=0 && py!=0) accum[(nx-1)+j] = (byte) 255;

							if (px!=0 && ny!=py && py!=0 && nx!=px) b1.set(i);
							if (px!=nx && ny!=0 && py!=ny && nx!=0) b1.set((nx-1)+nX*(ny-1));
						}
					}
				}

				// Check for PO* pattern in a 2x2 forward mask:  XY or YX
				//                                               YX    XY
				for (y=0; y<height-1; y++) {
					yp1 = y + 1;
					for (x=0; x<width-1; x++) {
						xp1 = x + 1;
						px = (int) ip3.getPixelValue(x,y);
						py = (int) ip4.getPixelValue(x,y);
						nx = (int) ip3.getPixelValue(xp1,y);
						ny = (int) ip4.getPixelValue(xp1,y);
						p2x = (int) ip3.getPixelValue(xp1,yp1);
						p2y = (int) ip4.getPixelValue(xp1,yp1);
						n2x = (int) ip3.getPixelValue(x,yp1);
						n2y = (int) ip4.getPixelValue(x,yp1);

						if ((px==0 && py!=0 && nx!=0 && ny==0 && p2x==0 && p2y!=0 && n2x!=0 && n2y==0) || (px!=0 && py==0 && nx==0 && ny!=0 && p2x!=0 && p2y==0 && n2x==0 && n2y!=0)) accum[(Math.max(px,nx)-1)+nX*(Math.max(py,ny)-1)]=(byte) 64 ;
					}
				}

				// Process the RCC8D table into RCC8D+
				for (y=0; y<nY; y++) {
					yoffset = y * nX;
					for (x=0; x<nX; x++) {
						i = x + yoffset;
						bx = accum [i]; // Adjacency test 1
						by = pixels[i]; // RCC8D table
						bz = b1.get(i); // Adjacency test 2
						if (by == (byte) 5) {
							if (bx == (byte) 255) // if DC and regions are adjacent <= sqrt(8) -> NC
								pixels[i] = (byte) 13;
							else 
								pixels[i] = (byte) 17; // DC+ are those DC which are not NC
						}
						else if (by == (byte) 8) { 
							if (bz) // if NTPP and overlap is adjacent to background -> NCNTPP
								pixels[i] = (byte) 11;
							else
								pixels[i] = (byte) 15; // NTPP+
						}
						else if (by == (byte) 10) {
							if (bz) // if NTPPi and overlap is adjacent to background -> NCNTPPi
								pixels[i] = (byte) 12;
							else
								pixels[i] = (byte) 16; // NTPPi+
						}
						else if (by == (byte) 6) {
							if (bx == (byte) 64) // If EC and pattern is 1001 or 0110 -> PO*
								pixels[i] = (byte) 14;
							else
								pixels[i] = (byte) 18; // EC+
						}
					}
				}
				//startTime8 = System.currentTimeMillis()-startTime8;
				//IJ.log("Process8+:" + startTime8);
			}
		}

		impT.updateAndDraw();
		imp3.close();
		imp4.close();

		ImageStatistics stats;
		stats = impT.getStatistics();

		if (details) {
			startTime=System.currentTimeMillis()-startTime;
			IJ.log("---- RCC8D_Multi v2.5 ----");
			IJ.log("ImageX: " + imp1.getTitle());
			IJ.log("RegionsX: " + nX);
			IJ.log("ImageY: " + imp2.getTitle());
			IJ.log("RegionsY: " + nY);
			IJ.log("Mode: " + mode);
			IJ.log("Relations: " + nXtnY);
			IJ.log("O-relations: " + nO);
			IJ.log("Processing_time_(sec.): " + startTime / 1000.0);
			for (i=0; i<slattice.length-2; i++) 
				IJ.log("" + slattice[i] + " " + relationName1[slattice[i]] + ": " + stats.histogram[slattice[i]]);
		}

		TextWindow win = rt.getResultsWindow();
		if (win!=null) win.close(false); // "false" so do not ask to save it

		ImagePlus impL=null;
		if (legend) {
			impL = IJ.createImage(mode + " Legend", "8-bit Black", 190, (int)((slattice.length - 0.3) * 16), 1);
			ImageProcessor ipL = impL.getProcessor();
			ipL.setFont(new Font("SanSerif", Font.BOLD, 12));
			ipL.setColor(80);
			ipL.moveTo(4, 15);
			ipL.drawString("Relation(X,Y)   Code    Colour");
			ipL.setFont(new Font("SanSerif", Font.PLAIN, 12));

			for (i=0; i<slattice.length-2; i++) {
				ipL.setColor(80);
				ipL.moveTo(28, (2 + i ) * 16);
				ipL.drawString(relationName1[slattice[i]]);
				ipL.moveTo(102, (2 + i) * 16);
				ipL.drawString("" + slattice[i]);
				ipL.setColor(slattice[i]);
				ipL.setRoi(156, (2 + i) * 16 - 13, 11, 11);
				ipL.fill();
			}

			if (mode.equals("RCC5D")) {
				ipL.setColor(80);
				ipL.drawRect(156, (2) * 16 - 13, 11, 11);
			}
			//impL.updateAndDraw();
			IJ.run(impL, "glasbey", "");
		}
		return new Object[] {impT, impL};
	}
}
